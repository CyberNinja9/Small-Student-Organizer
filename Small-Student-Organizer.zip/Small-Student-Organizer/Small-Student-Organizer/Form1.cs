﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Small_Student_Organizer
{
    public partial class Form1 : Form
    {
        public string StudentName { get; private set; }
        public string LastName { get; private set; }
        public string StudentClass { get; private set; }
        public int ID { get; private set; }

        public Form1()
        {
            InitializeComponent();
            InitializeForm();
        }

        private void InitializeForm()
        {

            ClassComboBox.Items.AddRange(new string[] { "OOP", "Java", "Math" });
            ClassComboBox.SelectedIndex = 0;


            IDTextBox.Text = "";
        }

        private void AddStudentButton_Click(object sender, EventArgs e)
        {
            if (int.TryParse(IDTextBox.Text, out int enteredID))
            {
                StudentName = NameTextBox.Text;
                LastName = LastNameTextBox.Text;
                StudentClass = ClassComboBox.SelectedItem.ToString();
                ID = enteredID;

                MessageBox.Show($"Student has been added. ID: {ID}", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Please enter a valid ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}