﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Small_Student_Organizer
{
    public partial class Form3 : Form
    {
        private Dictionary<string, List<Student>> studentDictionary = new Dictionary<string, List<Student>>();

        public Form3()
        {
            InitializeComponent();
            InitializeForm();
        }

        private void InitializeForm() => this.FormBorderStyle = FormBorderStyle.FixedSingle;

        private void AddStudentButton_Click(object sender, EventArgs e)
        {
            Form1 addStudentForm = new Form1();
            addStudentForm.ShowDialog();


            if (!string.IsNullOrEmpty(addStudentForm.StudentName) && !string.IsNullOrEmpty(addStudentForm.LastName))
            {

                string studentName = addStudentForm.StudentName;
                string lastName = addStudentForm.LastName;
                string studentClass = addStudentForm.StudentClass;
                int id = addStudentForm.ID;


                Student newStudent = new Student(studentName, lastName, studentClass, id);


                if (!studentDictionary.ContainsKey(studentClass))
                {
                    studentDictionary[studentClass] = new List<Student>();
                }


                studentDictionary[studentClass].Add(newStudent);
            }
        }

        private void SeeStudentsButton_Click(object sender, EventArgs e)
        {
            Form2 seeStudentsForm = new Form2(studentDictionary);
            seeStudentsForm.ShowDialog();
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }
    }
}