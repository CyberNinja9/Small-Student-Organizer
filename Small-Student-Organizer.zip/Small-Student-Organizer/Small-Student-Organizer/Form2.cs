﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace Small_Student_Organizer
{
    public partial class Form2 : Form
    {
        private Dictionary<string, List<Student>> studentDictionary;

        public Form2(Dictionary<string, List<Student>> dictionary)
        {
            InitializeComponent();
            studentDictionary = dictionary;
            InitializeForm();
        }

        private void InitializeForm()
        {

            ClassComboBox.Items.Add("All");
            foreach (var key in studentDictionary.Keys)
            {
                ClassComboBox.Items.Add(key);
            }
            ClassComboBox.SelectedIndex = 0;


            this.FormBorderStyle = FormBorderStyle.FixedSingle;
        }

        private void ClassComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedClass = ClassComboBox.SelectedItem.ToString();
            StudentListBox.Items.Clear();

            if (selectedClass == "All")
            {

                foreach (var studentList in studentDictionary.Values)
                {
                    foreach (var student in studentList)
                    {
                        StudentListBox.Items.Add(student.ID);
                    }
                }
            }
            else if (studentDictionary.ContainsKey(selectedClass))
            {
                foreach (var student in studentDictionary[selectedClass])
                {
                    StudentListBox.Items.Add(student.ID);
                }
            }
        }

        private void StudentListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (StudentListBox.SelectedIndex != -1)
            {
                int selectedID = Convert.ToInt32(StudentListBox.SelectedItem);
                string selectedClass = ClassComboBox.SelectedItem.ToString();

                Student student = null;
                if (selectedClass == "All")
                {
                    // Find the student in all classes
                    foreach (var studentList in studentDictionary.Values)
                    {
                        student = studentList.Find(s => s.ID == selectedID);
                        if (student != null) break;
                    }
                }
                else
                {
                    student = studentDictionary[selectedClass].Find(s => s.ID == selectedID);
                }

                if (student != null)
                {
                    // Update labels with student details
                    NameLabel.Text = student.StudentName;
                    LastNameLabel.Text = student.LastName;
                    IDLabel.Text = student.ID.ToString();
                    ClassLabel.Text = student.StudentClass;
                }
            }
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form2_Load(object sender, EventArgs e)
        {


        }
    }
}
