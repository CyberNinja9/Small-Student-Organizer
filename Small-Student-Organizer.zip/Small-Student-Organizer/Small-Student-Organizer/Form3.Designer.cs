﻿using System.Windows.Forms;

namespace Small_Student_Organizer
{
    partial class Form3 : Form
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.AddStudentButton = new System.Windows.Forms.Button();
            this.SeeStudentsButton = new System.Windows.Forms.Button();
            this.ExitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();


            this.AddStudentButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.AddStudentButton.ForeColor = System.Drawing.Color.Black;
            this.AddStudentButton.Location = new System.Drawing.Point(67, 62);
            this.AddStudentButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.AddStudentButton.Name = "AddStudentButton";
            this.AddStudentButton.Size = new System.Drawing.Size(200, 62);
            this.AddStudentButton.TabIndex = 0;
            this.AddStudentButton.Text = "Add Student";
            this.AddStudentButton.UseVisualStyleBackColor = false;
            this.AddStudentButton.Click += new System.EventHandler(this.AddStudentButton_Click);


            this.SeeStudentsButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(102)))), ((int)(((byte)(204)))), ((int)(((byte)(255)))));
            this.SeeStudentsButton.ForeColor = System.Drawing.Color.White;
            this.SeeStudentsButton.Location = new System.Drawing.Point(67, 148);
            this.SeeStudentsButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.SeeStudentsButton.Name = "SeeStudentsButton";
            this.SeeStudentsButton.Size = new System.Drawing.Size(200, 62);
            this.SeeStudentsButton.TabIndex = 1;
            this.SeeStudentsButton.Text = "See Students";
            this.SeeStudentsButton.UseVisualStyleBackColor = false;
            this.SeeStudentsButton.Click += new System.EventHandler(this.SeeStudentsButton_Click);


            this.ExitButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.ExitButton.ForeColor = System.Drawing.Color.White;
            this.ExitButton.Location = new System.Drawing.Point(67, 234);
            this.ExitButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(200, 62);
            this.ExitButton.TabIndex = 2;
            this.ExitButton.Text = "Exit";
            this.ExitButton.UseVisualStyleBackColor = false;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);


            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(333, 369);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.SeeStudentsButton);
            this.Controls.Add(this.AddStudentButton);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form3";
            this.Text = "Main Form";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.ResumeLayout(false);

        }

        private System.Windows.Forms.Button AddStudentButton;
        private System.Windows.Forms.Button SeeStudentsButton;
        private System.Windows.Forms.Button ExitButton;
    }
}