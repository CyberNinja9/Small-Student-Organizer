﻿using System.Windows.Forms;

namespace Small_Student_Organizer
{
    partial class Form2 : Form
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.ClassComboBox = new System.Windows.Forms.ComboBox();
            this.StudentListBox = new System.Windows.Forms.ListBox();
            this.NameLabel = new System.Windows.Forms.Label();
            this.LastNameLabel = new System.Windows.Forms.Label();
            this.IDLabel = new System.Windows.Forms.Label();
            this.ClassLabel = new System.Windows.Forms.Label();
            this.ExitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();

            this.ClassComboBox.BackColor = System.Drawing.Color.LightGray;
            this.ClassComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ClassComboBox.FormattingEnabled = true;
            this.ClassComboBox.Location = new System.Drawing.Point(67, 32);
            this.ClassComboBox.Margin = new System.Windows.Forms.Padding(4);
            this.ClassComboBox.Name = "ClassComboBox";
            this.ClassComboBox.Size = new System.Drawing.Size(265, 24);
            this.ClassComboBox.TabIndex = 0;
            this.ClassComboBox.SelectedIndexChanged += new System.EventHandler(this.ClassComboBox_SelectedIndexChanged);

            this.StudentListBox.BackColor = System.Drawing.Color.White;
            this.StudentListBox.FormattingEnabled = true;
            this.StudentListBox.ItemHeight = 16;
            this.StudentListBox.Location = new System.Drawing.Point(67, 98);
            this.StudentListBox.Margin = new System.Windows.Forms.Padding(4);
            this.StudentListBox.Name = "StudentListBox";
            this.StudentListBox.Size = new System.Drawing.Size(265, 196);
            this.StudentListBox.TabIndex = 1;
            this.StudentListBox.SelectedIndexChanged += new System.EventHandler(this.StudentListBox_SelectedIndexChanged);

            this.NameLabel.AutoSize = true;
            this.NameLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(255)))));
            this.NameLabel.Location = new System.Drawing.Point(400, 98);
            this.NameLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.NameLabel.Name = "NameLabel";
            this.NameLabel.Size = new System.Drawing.Size(47, 16);
            this.NameLabel.TabIndex = 2;
            this.NameLabel.Text = "Name:";

            this.LastNameLabel.AutoSize = true;
            this.LastNameLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(255)))));
            this.LastNameLabel.Location = new System.Drawing.Point(400, 135);
            this.LastNameLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.LastNameLabel.Name = "LastNameLabel";
            this.LastNameLabel.Size = new System.Drawing.Size(75, 16);
            this.LastNameLabel.TabIndex = 3;
            this.LastNameLabel.Text = "Last Name:";

            this.IDLabel.AutoSize = true;
            this.IDLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(255)))));
            this.IDLabel.Location = new System.Drawing.Point(400, 172);
            this.IDLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.IDLabel.Name = "IDLabel";
            this.IDLabel.Size = new System.Drawing.Size(23, 16);
            this.IDLabel.TabIndex = 4;
            this.IDLabel.Text = "ID:";

            this.ClassLabel.AutoSize = true;
            this.ClassLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(255)))));
            this.ClassLabel.Location = new System.Drawing.Point(400, 209);
            this.ClassLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.ClassLabel.Name = "ClassLabel";
            this.ClassLabel.Size = new System.Drawing.Size(44, 16);
            this.ClassLabel.TabIndex = 5;
            this.ClassLabel.Text = "Class:";


            this.ExitButton.BackColor = System.Drawing.Color.Gold;
            this.ExitButton.ForeColor = System.Drawing.Color.Black;
            this.ExitButton.Location = new System.Drawing.Point(400, 271);
            this.ExitButton.Margin = new System.Windows.Forms.Padding(4);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(100, 28);
            this.ExitButton.TabIndex = 6;
            this.ExitButton.Text = "Exit";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);


            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.ClientSize = new System.Drawing.Size(533, 332);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.ClassLabel);
            this.Controls.Add(this.IDLabel);
            this.Controls.Add(this.LastNameLabel);
            this.Controls.Add(this.NameLabel);
            this.Controls.Add(this.StudentListBox);
            this.Controls.Add(this.ClassComboBox);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form2";
            this.Text = "See Students";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private System.Windows.Forms.ComboBox ClassComboBox;
        private System.Windows.Forms.ListBox StudentListBox;
        private System.Windows.Forms.Label NameLabel;
        private System.Windows.Forms.Label LastNameLabel;
        private System.Windows.Forms.Label IDLabel;
        private System.Windows.Forms.Label ClassLabel;
        private System.Windows.Forms.Button ExitButton;
    }
}
